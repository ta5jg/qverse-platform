

"""
Q-Verse Audit Engine V9

Purpose:
    Difference Analyzer Layer

Relationship:
    State Engine   = Current State
    Config Engine  = Desired State
    Audit Engine   = Current vs Desired Analyzer
    Backup Engine  = Safety Layer
    Installer      = Execution Engine
"""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

import hashlib
import json


AUDIT_ENGINE_VERSION = 'V9'


@dataclass
class AuditFinding:
    severity: str
    category: str
    message: str
    current: Optional[Any] = None
    desired: Optional[Any] = None


@dataclass
class AuditAction:
    action: str
    category: str
    command: Optional[str] = None
    risk: str = 'low'
    requires_backup: bool = False


@dataclass
class AuditRisk:
    severity: str
    component: str
    impact: str


@dataclass
class AuditCompliance:
    passed: bool
    score: int
    failed_checks: List[str] = field(default_factory=list)


@dataclass
class AuditSummary:
    score: int
    health: str
    deployment_ready: bool
    finding_count: int
    critical_count: int
    action_count: int
    next_action: str


@dataclass
class AuditReport:
    version: str
    generated_at: str
    environment: str
    findings: List[AuditFinding] = field(default_factory=list)
    actions: List[AuditAction] = field(default_factory=list)
    risks: List[AuditRisk] = field(default_factory=list)
    compliance: Optional[AuditCompliance] = None
    summary: Optional[AuditSummary] = None
    checksum: Optional[str] = None


class AuditEngine:
    """Compares current system state against desired configuration state."""

    def __init__(self, reports_dir: str = '.qverse_audit'):
        self.reports_dir = Path(reports_dir)
        self.reports_dir.mkdir(exist_ok=True)

    def now(self) -> str:
        return datetime.now(timezone.utc).isoformat()

    def as_dict(self, value: Any) -> Dict[str, Any]:
        if value is None:
            return {}

        if isinstance(value, dict):
            return value

        if hasattr(value, '__dataclass_fields__'):
            return asdict(value)

        return {}

    def calculate_checksum(self, data: Dict[str, Any]) -> str:
        payload = json.dumps(data, sort_keys=True, default=str)
        return hashlib.sha256(payload.encode('utf-8')).hexdigest()

    def add_finding(
        self,
        findings: List[AuditFinding],
        severity: str,
        category: str,
        message: str,
        current: Optional[Any] = None,
        desired: Optional[Any] = None,
    ) -> None:
        findings.append(
            AuditFinding(
                severity=severity,
                category=category,
                message=message,
                current=current,
                desired=desired,
            )
        )

    def normalize_current_state(self, current_state: Any) -> Dict[str, Any]:
        data = self.as_dict(current_state)

        if 'state' in data:
            return data['state']

        return data

    def normalize_desired_state(self, desired_state: Any) -> Dict[str, Any]:
        return self.as_dict(desired_state)

    def audit_services(
        self,
        current: Dict[str, Any],
        desired: Dict[str, Any],
        findings: List[AuditFinding],
        actions: List[AuditAction],
    ) -> None:
        current_services = {
            item.get('name'): item
            for item in current.get('services', [])
            if isinstance(item, dict)
        }

        desired_services = desired.get('services', {}) or {}

        for name, cfg in desired_services.items():
            if not cfg.get('enabled') and not cfg.get('required'):
                continue

            installed = bool(current_services.get(name, {}).get('installed'))

            if not installed:
                self.add_finding(
                    findings,
                    'high' if cfg.get('required') else 'medium',
                    'service',
                    f'Service missing: {name}',
                    current=False,
                    desired=True,
                )
                actions.append(
                    AuditAction(
                        action=f'install_{name}',
                        category='service',
                        command=f'install service {name}',
                        risk='medium',
                        requires_backup=False,
                    )
                )

    def audit_security(
        self,
        current: Dict[str, Any],
        desired: Dict[str, Any],
        findings: List[AuditFinding],
        actions: List[AuditAction],
    ) -> None:
        security = desired.get('security', {}) or {}
        ssl_required = security.get('ssl_required', True)
        firewall_required = security.get('firewall_required', True)
        backups_required = security.get('backups_required', True)

        ssl_enabled = bool(current.get('ssl', {}).get('enabled'))
        firewall_installed = bool(current.get('firewall', {}).get('ufw_installed'))
        backups = current.get('backups', []) or []

        if ssl_required and not ssl_enabled:
            self.add_finding(
                findings,
                'critical',
                'security',
                'SSL is required but not enabled',
                current=False,
                desired=True,
            )
            actions.append(
                AuditAction(
                    action='configure_ssl',
                    category='security',
                    command='certbot --nginx',
                    risk='medium',
                    requires_backup=True,
                )
            )

        if firewall_required and not firewall_installed:
            self.add_finding(
                findings,
                'high',
                'security',
                'Firewall is required but not installed',
                current=False,
                desired=True,
            )
            actions.append(
                AuditAction(
                    action='install_firewall',
                    category='security',
                    command='apt-get install ufw -y',
                    risk='low',
                    requires_backup=False,
                )
            )

        if backups_required and not backups:
            self.add_finding(
                findings,
                'high',
                'backup',
                'Backups are required but no backup inventory was found',
                current=0,
                desired='>0',
            )
            actions.append(
                AuditAction(
                    action='configure_backup_system',
                    category='backup',
                    command='configure qverse backups',
                    risk='medium',
                    requires_backup=False,
                )
            )

    def audit_api_and_admin(
        self,
        current: Dict[str, Any],
        findings: List[AuditFinding],
        actions: List[AuditAction],
    ) -> None:
        api_reachable = bool(current.get('api_health', {}).get('reachable'))
        admin_installed = bool(current.get('admin_panel', {}).get('installed'))

        if not api_reachable:
            self.add_finding(
                findings,
                'critical',
                'api',
                'Q-Verse API is not reachable',
                current=False,
                desired=True,
            )
            actions.append(
                AuditAction(
                    action='deploy_or_restart_qverse_api',
                    category='api',
                    command='systemctl restart qverse-ai-api',
                    risk='low',
                    requires_backup=False,
                )
            )

        if not admin_installed:
            self.add_finding(
                findings,
                'medium',
                'frontend',
                'Admin Panel is not installed',
                current=False,
                desired=True,
            )
            actions.append(
                AuditAction(
                    action='install_admin_panel',
                    category='frontend',
                    command='build and deploy admin panel',
                    risk='medium',
                    requires_backup=True,
                )
            )

    def audit_databases(
        self,
        current: Dict[str, Any],
        desired: Dict[str, Any],
        findings: List[AuditFinding],
        actions: List[AuditAction],
    ) -> None:
        desired_databases = desired.get('databases', {}) or {}
        current_databases = current.get('databases', {}) or {}

        for name, cfg in desired_databases.items():
            if not cfg.get('enabled'):
                continue

            installed = bool(current_databases.get(name))

            if not installed:
                self.add_finding(
                    findings,
                    'high',
                    'database',
                    f'Database required but missing: {name}',
                    current=False,
                    desired=True,
                )
                actions.append(
                    AuditAction(
                        action=f'install_database_{name}',
                        category='database',
                        command=f'install database {name}',
                        risk='medium',
                        requires_backup=True,
                    )
                )

    def build_risks(self, findings: List[AuditFinding]) -> List[AuditRisk]:
        risks = []

        for finding in findings:
            if finding.severity in {'critical', 'high'}:
                risks.append(
                    AuditRisk(
                        severity=finding.severity,
                        component=finding.category,
                        impact=finding.message,
                    )
                )

        return risks

    def build_compliance(self, findings: List[AuditFinding]) -> AuditCompliance:
        failed = [f.category for f in findings if f.severity in {'critical', 'high'}]
        penalty = 0

        for finding in findings:
            if finding.severity == 'critical':
                penalty += 25
            elif finding.severity == 'high':
                penalty += 15
            elif finding.severity == 'medium':
                penalty += 8
            else:
                penalty += 3

        score = max(0, 100 - penalty)

        return AuditCompliance(
            passed=len(failed) == 0,
            score=score,
            failed_checks=sorted(set(failed)),
        )

    def build_summary(
        self,
        findings: List[AuditFinding],
        actions: List[AuditAction],
        compliance: AuditCompliance,
    ) -> AuditSummary:
        critical_count = len([f for f in findings if f.severity == 'critical'])

        if compliance.score >= 90:
            health = 'excellent'
        elif compliance.score >= 75:
            health = 'good'
        elif compliance.score >= 50:
            health = 'warning'
        else:
            health = 'critical'

        next_action = actions[0].action if actions else 'none'

        return AuditSummary(
            score=compliance.score,
            health=health,
            deployment_ready=critical_count == 0 and compliance.passed,
            finding_count=len(findings),
            critical_count=critical_count,
            action_count=len(actions),
            next_action=next_action,
        )

    def run_audit(
        self,
        current_state: Any,
        desired_state: Any,
    ) -> AuditReport:
        current = self.normalize_current_state(current_state)
        desired = self.normalize_desired_state(desired_state)

        findings: List[AuditFinding] = []
        actions: List[AuditAction] = []

        self.audit_services(current, desired, findings, actions)
        self.audit_security(current, desired, findings, actions)
        self.audit_api_and_admin(current, findings, actions)
        self.audit_databases(current, desired, findings, actions)

        risks = self.build_risks(findings)
        compliance = self.build_compliance(findings)
        summary = self.build_summary(findings, actions, compliance)

        report = AuditReport(
            version=AUDIT_ENGINE_VERSION,
            generated_at=self.now(),
            environment=desired.get('environment', 'unknown'),
            findings=findings,
            actions=actions,
            risks=risks,
            compliance=compliance,
            summary=summary,
        )

        report.checksum = self.calculate_checksum(asdict(report))
        return report

    def export_json(self, report: AuditReport) -> Dict[str, Any]:
        return asdict(report)

    def export_markdown(self, report: AuditReport) -> str:
        lines = [
            f'# Q-Verse Audit Report',
            '',
            f'- Version: {report.version}',
            f'- Environment: {report.environment}',
            f'- Generated At: {report.generated_at}',
            f'- Score: {report.summary.score if report.summary else "n/a"}',
            f'- Health: {report.summary.health if report.summary else "n/a"}',
            f'- Deployment Ready: {report.summary.deployment_ready if report.summary else False}',
            f'- Findings: {len(report.findings)}',
            f'- Actions: {len(report.actions)}',
            '',
            '## Findings',
        ]

        for finding in report.findings:
            lines.append(
                f'- [{finding.severity}] {finding.category}: {finding.message}'
            )

        lines.append('')
        lines.append('## Actions')

        for action in report.actions:
            lines.append(
                f'- {action.action} ({action.category}, risk={action.risk})'
            )

        return '\n'.join(lines)

    def save_report(self, report: AuditReport) -> Path:
        timestamp = datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')
        target = self.reports_dir / f'audit_{timestamp}.json'
        target.write_text(
            json.dumps(self.export_json(report), indent=2, default=str),
            encoding='utf-8',
        )
        return target