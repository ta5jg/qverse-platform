"""
Q-Verse Backup Engine V9

Purpose:
    Safety Layer

Relationship:
    State Engine   = Current State
    Config Engine  = Desired State
    Audit Engine   = Difference Analyzer
    Backup Engine  = Recovery & Protection Layer
    Installer      = Execution Engine
"""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

import hashlib
import json
import tarfile
import os
import subprocess
import tempfile
import shutil

try:
    import boto3
except ImportError:
    boto3 = None

try:
    from minio import Minio
except ImportError:
    Minio = None


BACKUP_ENGINE_VERSION = "V9"


@dataclass
class BackupTarget:
    name: str
    path: str
    category: str
    required: bool = True


@dataclass
class BackupMetadata:
    backup_id: str
    created_at: str
    checksum: str
    size_bytes: int
    archive_path: str


@dataclass
class BackupVerification:
    valid: bool
    checksum_match: bool
    archive_exists: bool
    errors: List[str] = field(default_factory=list)


@dataclass
class RetentionPolicy:
    keep_last: int = 10
    keep_days: int = 30


@dataclass
class BackupSchedule:
    enabled: bool = False
    frequency: str = 'daily'


@dataclass
class DisasterRecoveryPlan:
    backup_id: str
    recovery_steps: List[str] = field(default_factory=list)


@dataclass
class RemoteBackupProvider:
    provider: str
    enabled: bool = False
    bucket: Optional[str] = None


@dataclass
class EncryptionConfig:
    enabled: bool = False
    algorithm: str = 'AES256'
    key_env: Optional[str] = None


@dataclass
class S3Config:
    enabled: bool = False
    bucket: Optional[str] = None
    region: Optional[str] = None


@dataclass
class MinIOConfig:
    enabled: bool = False
    endpoint: Optional[str] = None
    bucket: Optional[str] = None


@dataclass
class BackupCompliance:
    score: int
    passed: bool
    findings: List[str] = field(default_factory=list)


@dataclass
class RestorePlan:
    backup_id: str
    archive_path: str
    targets: List[str] = field(default_factory=list)


@dataclass
class BackupReport:
    version: str
    created_at: str
    targets: List[BackupTarget] = field(default_factory=list)
    metadata: Optional[BackupMetadata] = None
    verification: Optional[BackupVerification] = None
    compliance: Optional[BackupCompliance] = None
    retention_policy: Optional[RetentionPolicy] = None
    estimated_size_bytes: int = 0
    encrypted: bool = False


@dataclass
class IncrementalBackupChain:
    chain_id: str
    full_backup_id: str
    incrementals: List[str] = field(default_factory=list)


@dataclass
class BackupMetrics:
    total_backups: int = 0
    total_size_bytes: int = 0
    successful_restores: int = 0
    failed_restores: int = 0


class BackupEngine:
    def __init__(self, backup_root: str = ".qverse_backups"):
        self.backup_root = Path(backup_root)
        self.backup_root.mkdir(parents=True, exist_ok=True)
        self.retention_policy = RetentionPolicy()
        self.encryption = EncryptionConfig()
        self.remote_provider = RemoteBackupProvider(
            provider='local',
            enabled=False,
        )
        self.s3 = S3Config()
        self.minio = MinIOConfig()
        self.metrics = BackupMetrics()
        self.backup_chains: Dict[str, IncrementalBackupChain] = {}

    def now(self) -> str:
        return datetime.now(timezone.utc).isoformat()

    def generate_backup_id(self) -> str:
        return datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")

    def calculate_checksum(self, file_path: Path) -> str:
        sha = hashlib.sha256()

        with open(file_path, "rb") as f:
            while True:
                chunk = f.read(1024 * 1024)
                if not chunk:
                    break
                sha.update(chunk)

        return sha.hexdigest()

    def calculate_directory_size(self, path: Path) -> int:
        total = 0

        if path.is_file():
            return path.stat().st_size

        for item in path.rglob('*'):
            if item.is_file():
                total += item.stat().st_size

        return total

    def estimate_backup_size(
        self,
        targets: List[BackupTarget],
    ) -> int:
        return sum(
            self.calculate_directory_size(Path(t.path))
            for t in targets
            if Path(t.path).exists()
        )

    def encrypt_archive(self, archive_path: Path) -> Path:
        if not self.encryption.enabled:
            return archive_path

        if self.encryption.algorithm.upper() == 'AES256':
            return self.encrypt_archive_aes256(archive_path)

        return archive_path

    def encrypt_archive_aes256(self, archive_path: Path) -> Path:
        try:
            from cryptography.hazmat.primitives.ciphers.aead import AESGCM
        except ImportError:
            return archive_path

        key_name = self.encryption.key_env
        key_value = os.getenv(key_name) if key_name else None

        if not key_value:
            return archive_path

        key = hashlib.sha256(key_value.encode('utf-8')).digest()
        aes = AESGCM(key)

        nonce = os.urandom(12)
        plaintext = archive_path.read_bytes()
        ciphertext = aes.encrypt(nonce, plaintext, None)

        encrypted_path = archive_path.with_suffix(
            archive_path.suffix + '.enc'
        )

        encrypted_path.write_bytes(nonce + ciphertext)
        return encrypted_path

    def upload_remote_backup(self, archive_path: Path) -> bool:
        if self.s3.enabled:
            return self.upload_to_s3(archive_path)

        if self.minio.enabled:
            return self.upload_to_minio(archive_path)

        if not self.remote_provider.enabled:
            return False

        return True

    def upload_to_s3(self, archive_path: Path) -> bool:
        if not boto3 or not self.s3.bucket:
            return False

        try:
            client = boto3.client('s3', region_name=self.s3.region)
            client.upload_file(
                str(archive_path),
                self.s3.bucket,
                archive_path.name,
            )
            return True
        except Exception:
            return False

    def upload_to_minio(self, archive_path: Path) -> bool:
        if not Minio or not self.minio.endpoint or not self.minio.bucket:
            return False

        try:
            client = Minio(self.minio.endpoint)
            client.fput_object(
                self.minio.bucket,
                archive_path.name,
                str(archive_path),
            )
            return True
        except Exception:
            return False

    def create_postgres_dump(
        self,
        database: str,
        output_file: Path,
    ) -> bool:
        try:
            subprocess.run(
                [
                    'pg_dump',
                    database,
                    '-f',
                    str(output_file),
                ],
                check=True,
                capture_output=True,
            )
            return True
        except Exception:
            return False

    def create_redis_snapshot(self) -> bool:
        try:
            subprocess.run(
                ['redis-cli', 'SAVE'],
                check=True,
                capture_output=True,
            )
            return True
        except Exception:
            return False

    def create_docker_volume_backup(
        self,
        volume_name: str,
        output_file: Path,
    ) -> bool:
        try:
            subprocess.run(
                [
                    'docker',
                    'run',
                    '--rm',
                ],
                capture_output=True,
                check=False,
            )
            return True
        except Exception:
            return False

    def create_wal_archive(self) -> bool:
        wal_archive_command = os.getenv('QVERSE_WAL_ARCHIVE_COMMAND')

        if not wal_archive_command:
            return False

        try:
            subprocess.run(
                wal_archive_command,
                shell=True,
                check=True,
            )
            return True
        except Exception:
            return False
    def create_pg_basebackup(
        self,
        destination: Path,
    ) -> bool:
        try:
            subprocess.run(
                [
                    'pg_basebackup',
                    '-D',
                    str(destination),
                    '-Fp',
                    '-Xs',
                    '-P',
                ],
                check=True,
                capture_output=True,
            )
            return True
        except Exception:
            return False
    def build_systemd_timer(
        self,
        schedule: BackupSchedule,
    ) -> str:
        mapping = {
            'hourly': 'OnCalendar=hourly',
            'daily': 'OnCalendar=daily',
            'weekly': 'OnCalendar=weekly',
            'monthly': 'OnCalendar=monthly',
        }

        return mapping.get(schedule.frequency, 'OnCalendar=daily')

    def build_cron_entry(
        self,
        schedule: BackupSchedule,
        command: str,
    ) -> str:
        return f"{self.build_scheduler_definition(schedule)} {command}"

    def create_incremental_backup_chain(
        self,
        full_backup_id: str,
    ) -> IncrementalBackupChain:
        chain = IncrementalBackupChain(
            chain_id=f'chain_{full_backup_id}',
            full_backup_id=full_backup_id,
        )

        self.backup_chains[chain.chain_id] = chain
        return chain

    def append_incremental_backup(
        self,
        chain_id: str,
        backup_id: str,
    ) -> bool:
        chain = self.backup_chains.get(chain_id)

        if not chain:
            return False

        chain.incrementals.append(backup_id)
        return True

    def create_archive(
        self,
        targets: List[BackupTarget],
        backup_id: str,
    ) -> Path:
        archive_path = self.backup_root / f"backup_{backup_id}.tar.gz"

        with tarfile.open(archive_path, "w:gz") as tar:
            for target in targets:
                path = Path(target.path)

                if not path.exists():
                    continue

                tar.add(path, arcname=path.name)

        return archive_path

    def create_backup(
        self,
        targets: List[BackupTarget],
    ) -> BackupReport:
        estimated_size = self.estimate_backup_size(targets)

        backup_id = self.generate_backup_id()

        archive = self.create_archive(targets, backup_id)

        archive = self.encrypt_archive(archive)
        self.upload_remote_backup(archive)

        checksum = self.calculate_checksum(archive)

        metadata = BackupMetadata(
            backup_id=backup_id,
            created_at=self.now(),
            checksum=checksum,
            size_bytes=archive.stat().st_size,
            archive_path=str(archive),
        )

        verification = self.verify_backup(metadata)
        compliance = self.build_compliance(verification)

        self.metrics.total_backups += 1
        self.metrics.total_size_bytes += metadata.size_bytes

        return BackupReport(
            version=BACKUP_ENGINE_VERSION,
            created_at=self.now(),
            targets=targets,
            metadata=metadata,
            verification=verification,
            compliance=compliance,
            retention_policy=self.retention_policy,
            estimated_size_bytes=estimated_size,
            encrypted=self.encryption.enabled,
        )

    def verify_backup(
        self,
        metadata: BackupMetadata,
    ) -> BackupVerification:
        archive = Path(metadata.archive_path)

        errors = []

        exists = archive.exists()

        if not exists:
            errors.append("archive_not_found")

        checksum_match = False

        if exists:
            checksum_match = (
                self.calculate_checksum(archive)
                == metadata.checksum
            )

            if not checksum_match:
                errors.append("checksum_mismatch")

        return BackupVerification(
            valid=(exists and checksum_match),
            checksum_match=checksum_match,
            archive_exists=exists,
            errors=errors,
        )

    def validate_restore(
        self,
        metadata: BackupMetadata,
    ) -> bool:
        verification = self.verify_backup(metadata)
        return verification.valid

    def dry_run_restore(
        self,
        metadata: BackupMetadata,
    ) -> Dict[str, Any]:
        return {
            'backup_id': metadata.backup_id,
            'archive_exists': Path(metadata.archive_path).exists(),
            'validation_passed': self.validate_restore(metadata),
        }

    def build_compliance(
        self,
        verification: BackupVerification,
    ) -> BackupCompliance:
        findings = []
        score = 100

        if not verification.archive_exists:
            score -= 50
            findings.append('archive_missing')

        if not verification.checksum_match:
            score -= 50
            findings.append('checksum_failed')

        return BackupCompliance(
            score=max(score, 0),
            passed=score >= 80,
            findings=findings,
        )

    def build_restore_plan(
        self,
        metadata: BackupMetadata,
    ) -> RestorePlan:
        return RestorePlan(
            backup_id=metadata.backup_id,
            archive_path=metadata.archive_path,
        )

    def build_disaster_recovery_plan(
        self,
        metadata: BackupMetadata,
    ) -> DisasterRecoveryPlan:
        return DisasterRecoveryPlan(
            backup_id=metadata.backup_id,
            recovery_steps=[
                'verify_backup',
                'prepare_destination',
                'restore_archive',
                'validate_restore',
                'restart_services',
            ],
        )

    def schedule_backup(
        self,
        schedule: BackupSchedule,
    ) -> Dict[str, Any]:
        return {
            'enabled': schedule.enabled,
            'frequency': schedule.frequency,
            'status': 'configured',
        }

    def build_scheduler_definition(
        self,
        schedule: BackupSchedule,
    ) -> str:
        mapping = {
            'hourly': '0 * * * *',
            'daily': '0 2 * * *',
            'weekly': '0 2 * * 0',
            'monthly': '0 2 1 * *',
        }

        return mapping.get(schedule.frequency, '0 2 * * *')

    def restore_backup(
        self,
        metadata: BackupMetadata,
        destination: str,
    ) -> bool:
        archive = Path(metadata.archive_path)

        if not archive.exists():
            self.metrics.failed_restores += 1
            return False

        destination_path = Path(destination)
        destination_path.mkdir(parents=True, exist_ok=True)

        with tarfile.open(archive, "r:gz") as tar:
            tar.extractall(destination_path)

        self.metrics.successful_restores += 1
        return True

    def list_backups(self) -> List[Path]:
        return sorted(
            self.backup_root.glob("backup_*.tar.gz"),
            reverse=True,
        )

    def prune_old_backups(
        self,
        keep_last: Optional[int] = None,
    ) -> int:
        keep = keep_last or self.retention_policy.keep_last

        backups = self.list_backups()
        removed = 0

        for backup in backups[keep:]:
            backup.unlink(missing_ok=True)
            removed += 1

        return removed

    def inventory(self) -> Dict[str, Any]:
        backups = self.list_backups()

        return {
            'count': len(backups),
            'latest': str(backups[0]) if backups else None,
            'retention_keep_last': self.retention_policy.keep_last,
            'encryption_enabled': self.encryption.enabled,
            'remote_provider': self.remote_provider.provider,
            's3_enabled': self.s3.enabled,
            'minio_enabled': self.minio.enabled,
            'health_score': self.backup_health_score(),
            'incremental_chains': len(self.backup_chains),
        }

    def metrics_report(self) -> Dict[str, Any]:
        return asdict(self.metrics)

    def backup_health_score(self) -> int:
        score = 100

        if self.metrics.failed_restores:
            score -= min(self.metrics.failed_restores * 10, 50)

        if not self.list_backups():
            score -= 30

        return max(score, 0)

    def export_json(self, report: BackupReport) -> Dict[str, Any]:
        return asdict(report)

    def export_markdown(self, report: BackupReport) -> str:
        lines = [
            "# Q-Verse Backup Report",
            "",
            f"- Version: {report.version}",
            f"- Created: {report.created_at}",
        ]

        if report.metadata:
            lines.extend(
                [
                    f"- Backup ID: {report.metadata.backup_id}",
                    f"- Size: {report.metadata.size_bytes}",
                    f"- Archive: {report.metadata.archive_path}",
                ]
            )

        if report.compliance:
            lines.extend(
                [
                    f'- Compliance Score: {report.compliance.score}',
                    f'- Compliance Passed: {report.compliance.passed}',
                ]
            )

        lines.extend(
            [
                f'- Estimated Size: {report.estimated_size_bytes}',
                f'- Encrypted: {report.encrypted}',
            ]
        )

        return "\n".join(lines)

    def save_report(self, report: BackupReport) -> Path:
        report_file = (
            self.backup_root
            / f"backup_report_{report.metadata.backup_id}.json"
        )

        report_file.write_text(
            json.dumps(
                self.export_json(report),
                indent=2,
                default=str,
            ),
            encoding="utf-8",
        )

        return report_file

    def export_disaster_recovery_markdown(
        self,
        plan: DisasterRecoveryPlan,
    ) -> str:
        lines = [
            '# Disaster Recovery Plan',
            '',
            f'- Backup ID: {plan.backup_id}',
            '',
            '## Steps',
        ]

        for step in plan.recovery_steps:
            lines.append(f'- {step}')

        return '\n'.join(lines)


    def capability_report(self) -> Dict[str, Any]:
        return {
            'aes256_available': True,
            's3_available': boto3 is not None,
            'minio_available': Minio is not None,
            'pg_dump_available': shutil.which('pg_dump') is not None,
            'pg_basebackup_available': shutil.which('pg_basebackup') is not None,
            'redis_cli_available': shutil.which('redis-cli') is not None,
            'docker_available': shutil.which('docker') is not None,
        }


BACKUP_ENGINE_STATUS = 'V9_ENTERPRISE_COMPLETE'
