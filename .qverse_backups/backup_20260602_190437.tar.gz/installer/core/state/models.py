"""State Engine Models"""



@dataclass
class ServiceState:
    name: str
    installed: bool = False
    version: Optional[str] = None
    running: bool = False

@dataclass
class SystemState:
    hostname: str
    os_name: str
    os_version: str
    architecture: str
    hardware: Dict = field(default_factory=dict)
    packages: Dict = field(default_factory=dict)
    services: List[ServiceState] = field(default_factory=list)
    docker: Dict = field(default_factory=dict)
    databases: Dict = field(default_factory=dict)
    domains: List[str] = field(default_factory=list)
    ssl: Dict = field(default_factory=dict)
    qverse: Dict = field(default_factory=dict)
    models: Dict = field(default_factory=dict)
    integrations: Dict = field(default_factory=dict)
    projects: List[Dict] = field(default_factory=list)
    ram: Dict = field(default_factory=dict)
    disk: Dict = field(default_factory=dict)
    public_ip: Optional[str] = None
    firewall: Dict = field(default_factory=dict)
    systemd_services: List[str] = field(default_factory=list)
    containers: List[Dict] = field(default_factory=list)
    postgres_databases: List[str] = field(default_factory=list)
    redis_status: Dict = field(default_factory=dict)
    git_repositories: List[Dict] = field(default_factory=list)
    qverse_modules: List[str] = field(default_factory=list)
    admin_panel: Dict = field(default_factory=dict)
    api_health: Dict = field(default_factory=dict)
    backups: List[Dict] = field(default_factory=list)

@dataclass
class Recommendation:
    severity: str
    message: str

@dataclass
class StateAnalysis:
    score: int
    health: str
    missing_components: List[str] = field(default_factory=list)
    recommendations: List[Recommendation] = field(default_factory=list)

@dataclass
class EnvironmentProfile:
    environment: str
    confidence: int

@dataclass
class RiskItem:
    severity: str
    component: str
    impact: str

@dataclass
class ComplianceReport:
    passed: bool
    score: int
    failed_checks: List[str] = field(default_factory=list)

@dataclass
class InstallationPlan:
    actions: List[str] = field(default_factory=list)

@dataclass
class CapacityReport:
    max_agents: int
    profile: str

@dataclass
class DriftReport:
    detected: bool
    items: List[str] = field(default_factory=list)

@dataclass
class RepairAction:
    action: str
    command: str
    risk: str

@dataclass
class DeploymentReadiness:
    ready: bool
    blocking_issues: List[str] = field(default_factory=list)

@dataclass
class AIReadiness:
    score: int
    providers: Dict = field(default_factory=dict)

@dataclass
class ExecutiveSummary:
    health_score: int
    environment: str
    compliance_score: int
    deployment_ready: bool
    next_action: str

@dataclass
class SecurityScore:
    score: int
    findings: List[str] = field(default_factory=list)

@dataclass
class BackupReadiness:
    ready: bool
    backup_count: int

@dataclass
class ProviderReadiness:
    score: int
    available: List[str] = field(default_factory=list)

@dataclass
class CostEstimate:
    monthly_usd: float
    profile: str

@dataclass
class TelemetryReport:
    health_trend: str
    security_trend: str
    performance_trend: str

@dataclass
class BenchmarkReport:
    cpu_score: int
    ram_score: int
    disk_score: int
    overall_score: int

@dataclass
class PolicyReport:
    passed: bool
    violations: List[str] = field(default_factory=list)