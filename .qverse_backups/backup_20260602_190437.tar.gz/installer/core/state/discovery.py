"""Discovery Engine"""



def detect_hardware(self) -> Dict:
        return {
            'cpu_count': os.cpu_count(),
            'architecture': platform.machine(),
        }

def detect_packages(self) -> Dict:
        return {
            'python': self.get_version(['python3', '--version']),
            'git': self.get_version(['git', '--version']),
            'node': self.get_version(['node', '--version']),
            'npm': self.get_version(['npm', '--version']),
        }

def detect_docker(self) -> Dict:
        return {
            'installed': self.command_exists('docker'),
            'version': self.get_version(['docker', '--version']),
        }

def detect_databases(self) -> Dict:
        return {
            'postgres': self.command_exists('psql'),
            'redis': self.command_exists('redis-server'),
        }

def detect_domains(self) -> List[str]:
        nginx_dir = Path('/etc/nginx/sites-enabled')
        domains = []

        if nginx_dir.exists():
            for item in nginx_dir.iterdir():
                domains.append(item.name)

        return sorted(domains)

def detect_ssl(self) -> Dict:
        letsencrypt = Path('/etc/letsencrypt/live')

        return {
            'enabled': letsencrypt.exists(),
            'certificates': [p.name for p in letsencrypt.iterdir()] if letsencrypt.exists() else [],
        }

def detect_qverse(self) -> Dict:
        root = Path('/opt/ai-agents')

        return {
            'installed': root.exists(),
            'path': str(root),
        }

def detect_models(self) -> Dict:
        return {
            'gemini': True,
            'openai': True,
            'anthropic': True,
            'deepseek': True,
            'openrouter': True,
            'ollama': self.command_exists('ollama'),
            'lmstudio': False,
        }

def detect_integrations(self) -> Dict:
        return {
            'telegram': False,
            'discord': False,
            'slack': False,
            'signal': False,
            'whatsapp': False,
            'email': False,
        }

def detect_projects(self) -> List[Dict]:
        projects_dir = Path('/opt/ai-agents/projects')
        projects = []

        if projects_dir.exists():
            for project in projects_dir.iterdir():
                if project.is_dir():
                    projects.append({
                        'name': project.name,
                        'path': str(project),
                    })

        return sorted(projects, key=lambda p: p['name'])

def detect_ram(self) -> Dict:
        try:
            pages = os.sysconf('SC_PHYS_PAGES')
            page_size = os.sysconf('SC_PAGE_SIZE')
            total = pages * page_size
            return {'total_bytes': total}
        except Exception:
            return {}

def detect_disk_usage(self) -> Dict:
        usage = shutil.disk_usage('/')
        return {
            'total': usage.total,
            'used': usage.used,
            'free': usage.free,
        }

def detect_public_ip(self) -> Optional[str]:
        try:
            return urllib.request.urlopen('https://api.ipify.org', timeout=5).read().decode().strip()
        except Exception:
            return None

def detect_firewall(self) -> Dict:
        return {
            'ufw_installed': self.command_exists('ufw'),
        }

def detect_systemd_services(self) -> List[str]:
        try:
            result = subprocess.run(
                ['systemctl', 'list-units', '--type=service', '--state=running', '--no-legend'],
                capture_output=True,
                text=True,
                timeout=10,
            )
            return [line.split()[0] for line in result.stdout.splitlines() if line.strip()]
        except Exception:
            return []

def detect_running_containers(self) -> List[Dict]:
        if not self.command_exists('docker'):
            return []

        try:
            result = subprocess.run(
                ['docker', 'ps', '--format', '{{.Names}}|{{.Image}}'],
                capture_output=True,
                text=True,
                timeout=10,
            )
            containers = []
            for line in result.stdout.splitlines():
                if '|' in line:
                    name, image = line.split('|', 1)
                    containers.append({'name': name, 'image': image})
            return containers
        except Exception:
            return []

def detect_postgres_databases(self) -> List[str]:
        if not self.command_exists('psql'):
            return []

        try:
            result = subprocess.run(
                ['psql', '-lqt'],
                capture_output=True,
                text=True,
                timeout=10,
            )
            dbs = []
            for line in result.stdout.splitlines():
                if '|' in line:
                    dbs.append(line.split('|')[0].strip())
            return sorted(set(dbs))
        except Exception:
            return []

def detect_redis_status(self) -> Dict:
        return {
            'installed': self.command_exists('redis-server'),
            'running': self.service_running('redis'),
        }

def detect_git_repositories(self) -> List[Dict]:
        roots = [Path('/opt/ai-agents/projects')]
        repos = []

        for root in roots:
            if not root.exists():
                continue
            for item in root.iterdir():
                if (item / '.git').exists():
                    repos.append({'name': item.name, 'path': str(item)})

        return repos

def detect_qverse_modules(self) -> List[str]:
        modules = []
        installer_dir = Path.cwd().parent
        for name in ['core', 'services', 'models', 'integrations', 'frontend', 'database']:
            if (installer_dir / name).exists():
                modules.append(name)
        return modules

def detect_admin_panel(self) -> Dict:
        admin = Path('/opt/ai-agents/qverse-admin')
        return {
            'installed': admin.exists(),
            'path': str(admin),
        }

def detect_api_health(self) -> Dict:
        try:
            with urllib.request.urlopen('http://127.0.0.1:8787/health', timeout=3) as response:
                return {'reachable': response.status == 200}
        except Exception:
            return {'reachable': False}

def detect_backups(self) -> List[Dict]:
        backup_dir = Path('./backups')
        if not backup_dir.exists():
            return []

        return [
            {'name': f.name, 'size': f.stat().st_size}
            for f in backup_dir.iterdir()
            if f.is_file()
        ]

def detect_services(self) -> List[ServiceState]:
        services = []

        registry = [
            ('node', ['node', '--version'], 'node'),
            ('docker', ['docker', '--version'], 'docker'),
            ('postgres', ['psql', '--version'], 'postgres'),
            ('redis', ['redis-server', '--version'], 'redis'),
            ('nginx', ['nginx', '-v'], 'nginx'),
        ]

        for name, version_cmd, process_name in registry:
            installed = self.command_exists(version_cmd[0])
            version = self.get_version(version_cmd) if installed else None
            running = self.service_running(process_name)

            services.append(
                ServiceState(
                    name=name,
                    installed=installed,
                    version=version,
                    running=running,
                )
            )

        return services

def detect_drift(self, state: SystemState) -> DriftReport:
        drift = []

        if state.redis_status.get('installed') and not state.redis_status.get('running'):
            drift.append('redis_installed_but_not_running')

        if state.admin_panel.get('installed') and not state.api_health.get('reachable'):
            drift.append('admin_present_api_unreachable')

        if state.ssl.get('enabled') and not state.domains:
            drift.append('ssl_present_without_detected_domain')

        return DriftReport(
            detected=len(drift) > 0,
            items=drift,
        )