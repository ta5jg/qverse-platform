"""Compliance Engine"""



def evaluate_compliance(self, state: SystemState) -> ComplianceReport:
        failed = []
        score = 100

        if not state.ssl.get('enabled'):
            failed.append('ssl')
            score -= 25

        if not state.backups:
            failed.append('backup_policy')
            score -= 20

        if not state.api_health.get('reachable'):
            failed.append('api_health')
            score -= 25

        if not state.firewall.get('ufw_installed'):
            failed.append('firewall')
            score -= 10

        return ComplianceReport(
            passed=len(failed) == 0,
            score=max(0, score),
            failed_checks=failed,
        )

def evaluate_deployment_readiness(self, state: SystemState) -> DeploymentReadiness:
        blocking = []

        if not state.api_health.get('reachable'):
            blocking.append('api_unreachable')

        if not state.ssl.get('enabled'):
            blocking.append('ssl_missing')

        if not state.redis_status.get('installed'):
            blocking.append('redis_missing')

        return DeploymentReadiness(
            ready=len(blocking) == 0,
            blocking_issues=blocking,
        )

def evaluate_ai_readiness(self, state: SystemState) -> AIReadiness:
        providers = state.models.copy()

        score = 0
        for enabled in providers.values():
            if enabled:
                score += 10

        score = min(score, 100)

        return AIReadiness(
            score=score,
            providers=providers,
        )

def evaluate_security_score(self, state: SystemState) -> SecurityScore:
        score = 100
        findings = []

        if not state.ssl.get('enabled'):
            score -= 30
            findings.append('ssl_missing')

        if not state.firewall.get('ufw_installed'):
            score -= 15
            findings.append('firewall_missing')

        if not state.backups:
            score -= 15
            findings.append('backup_missing')

        return SecurityScore(max(0, score), findings)

def evaluate_backup_readiness(self, state: SystemState) -> BackupReadiness:
        return BackupReadiness(
            ready=len(state.backups) > 0,
            backup_count=len(state.backups),
        )

def evaluate_provider_readiness(self, state: SystemState) -> ProviderReadiness:
        available = [k for k, v in state.models.items() if v]

        return ProviderReadiness(
            score=min(100, len(available) * 10),
            available=available,
        )

def evaluate_policies(self, state: SystemState) -> PolicyReport:
        violations = []

        if not state.ssl.get('enabled'):
            violations.append('ssl_required')

        if not state.backups:
            violations.append('backup_required')

        if not state.firewall.get('ufw_installed'):
            violations.append('firewall_required')

        return PolicyReport(
            passed=len(violations) == 0,
            violations=violations,
        )