"""
Q-Verse Configuration Engine

Purpose:
    Desired State Definition Layer

Relationship:
    State Engine   = Current State
    Config Engine  = Desired State
    Audit Engine   = Difference Analyzer
    Installer      = Execution Engine
"""

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional

import yaml
import os
import copy
import json
import hashlib
from dataclasses import asdict


@dataclass
class ServiceConfig:
    enabled: bool = False
    required: bool = False
    version: Optional[str] = None


@dataclass
class SecurityConfig:
    ssl_required: bool = True
    firewall_required: bool = True
    backups_required: bool = True


@dataclass
class AIProviderConfig:
    enabled: bool = False
    api_key_env: Optional[str] = None
    model: Optional[str] = None


# --- Additional Config Classes ---
@dataclass
class ModuleConfig:
    enabled: bool = False
    required: bool = False


@dataclass
class DatabaseConfig:
    engine: str = 'postgresql'
    enabled: bool = False
    host: str = 'localhost'
    port: int = 5432


@dataclass
class IntegrationConfig:
    enabled: bool = False
    token_env: Optional[str] = None


@dataclass
class DeploymentConfig:
    environment: str = 'production'
    docker_enabled: bool = True
    nginx_enabled: bool = True


@dataclass
class MonitoringConfig:
    enabled: bool = True
    provider: str = 'internal'


@dataclass
class NotificationConfig:
    email_enabled: bool = False
    telegram_enabled: bool = False


@dataclass
class RepositoryConfig:
    git_enabled: bool = True
    branch: str = 'main'


@dataclass
class InstallerConfig:
    auto_repair: bool = True
    create_backups: bool = True


# --- V9 Additions ---
@dataclass
class ValidationIssue:
    severity: str
    message: str


@dataclass
class DependencyIssue:
    source: str
    target: str
    message: str


@dataclass
class ConfigDiff:
    changes: List[str] = field(default_factory=list)


# --- V9 Additions: Export, Checksum, ValidationReport, Profile ---
@dataclass
class ConfigExport:
    json: Dict[str, Any]
    yaml: str
    markdown: str


@dataclass
class ConfigChecksum:
    algorithm: str
    value: str


@dataclass
class ConfigValidationReport:
    valid: bool
    issues: List['ValidationIssue'] = field(default_factory=list)
    dependency_issues: List['DependencyIssue'] = field(default_factory=list)


@dataclass
class ConfigProfile:
    name: str
    inherits_from: Optional[str] = None
    description: Optional[str] = None


@dataclass
class EnvironmentConfig:
    name: str
    services: Dict[str, ServiceConfig] = field(default_factory=dict)
    security: SecurityConfig = field(default_factory=SecurityConfig)


@dataclass
class DesiredState:
    environment: str
    services: Dict[str, ServiceConfig] = field(default_factory=dict)
    providers: Dict[str, AIProviderConfig] = field(default_factory=dict)
    modules: Dict[str, ModuleConfig] = field(default_factory=dict)
    databases: Dict[str, DatabaseConfig] = field(default_factory=dict)
    integrations: Dict[str, IntegrationConfig] = field(default_factory=dict)
    deployment: Optional[DeploymentConfig] = None
    monitoring: Optional[MonitoringConfig] = None
    notifications: Optional[NotificationConfig] = None
    repository: Optional[RepositoryConfig] = None
    installer: Optional[InstallerConfig] = None
    security: SecurityConfig = field(default_factory=SecurityConfig)
    schema_version: int = 1
    validation_issues: List[ValidationIssue] = field(default_factory=list)
    dependency_issues: List[DependencyIssue] = field(default_factory=list)
    checksum: Optional[str] = None


class ConfigManager:
    """Loads and manages desired platform state."""

    def __init__(self, machine_dir: str = 'machine'):
        self.machine_dir = Path(machine_dir)

    def load_yaml(self, filename: str) -> Dict:
        target = self.machine_dir / filename

        if not target.exists():
            return {}

        with open(target, 'r', encoding='utf-8') as f:
            return yaml.safe_load(f) or {}

    def merge_dicts(self, base: Dict, override: Dict) -> Dict:
        result = copy.deepcopy(base)

        for key, value in override.items():
            if (
                key in result
                and isinstance(result[key], dict)
                and isinstance(value, dict)
            ):
                result[key] = self.merge_dicts(result[key], value)
            else:
                result[key] = value

        return result

    def resolve_secret(self, env_name: Optional[str]) -> Optional[str]:
        if not env_name:
            return None

        return os.getenv(env_name)

    def safe_dataclass(self, cls, data: Dict):
        if not data:
            return cls()

        allowed = cls.__dataclass_fields__.keys()
        filtered = {
            key: value
            for key, value in data.items()
            if key in allowed
        }

        return cls(**filtered)

    def normalize_collection(self, data: Any) -> Dict:
        if isinstance(data, dict):
            return data

        if isinstance(data, list):
            result = {}
            for item in data:
                if isinstance(item, dict):
                    key = item.get('id') or item.get('name')
                    if key:
                        result[key] = item
            return result

        return {}

    def normalize_config_item(self, value: Any) -> Dict:
        if isinstance(value, dict):
            return value

        if isinstance(value, list):
            merged = {}
            for item in value:
                if isinstance(item, dict):
                    merged.update(item)
            return merged

        return {}

    def state_to_dict(self, state: DesiredState) -> Dict[str, Any]:
        return asdict(state)

    def calculate_checksum(self, state: DesiredState) -> ConfigChecksum:
        payload = json.dumps(
            self.state_to_dict(state),
            sort_keys=True,
            default=str,
        )
        value = hashlib.sha256(payload.encode('utf-8')).hexdigest()
        return ConfigChecksum(algorithm='sha256', value=value)

    def load_environment(self, environment: str) -> Dict:
        return self.load_yaml(f'policies/{environment}.yaml')

    def load_modules(self) -> Dict:
        return self.load_yaml('modules.yaml')

    def load_services(self) -> Dict:
        return self.load_yaml('services.yaml')

    def load_models(self) -> Dict:
        return self.load_yaml('models.yaml')

    def load_database(self) -> Dict:
        return self.load_yaml('database.yaml')

    def load_integrations(self) -> Dict:
        return self.load_yaml('integrations.yaml')

    def load_deployment(self) -> Dict:
        return self.load_yaml('deployment.yaml')

    def load_monitoring(self) -> Dict:
        return self.load_yaml('monitoring.yaml')

    def load_notifications(self) -> Dict:
        return self.load_yaml('notifications.yaml')

    def load_repository(self) -> Dict:
        return self.load_yaml('repository.yaml')

    def load_installer(self) -> Dict:
        return self.load_yaml('installer.yaml')

    def validate_desired_state(self, state: DesiredState) -> List[ValidationIssue]:
        issues = []

        if not state.environment:
            issues.append(
                ValidationIssue(
                    severity='critical',
                    message='Environment name is required',
                )
            )

        if state.security.ssl_required and not state.deployment.nginx_enabled:
            issues.append(
                ValidationIssue(
                    severity='high',
                    message='SSL requires nginx_enabled=True',
                )
            )

        for name, service in state.services.items():
            if service.required and not service.enabled:
                issues.append(
                    ValidationIssue(
                        severity='high',
                        message=f'Required service disabled: {name}',
                    )
                )

        for name, database in state.databases.items():
            if database.enabled and not database.host:
                issues.append(
                    ValidationIssue(
                        severity='high',
                        message=f'Database host missing: {name}',
                    )
                )

        return issues

    def validate_dependencies(self, state: DesiredState) -> List[DependencyIssue]:
        issues = []

        enabled_databases = [
            name for name, db in state.databases.items()
            if db.enabled
        ]

        if enabled_databases and not state.installer.create_backups:
            issues.append(
                DependencyIssue(
                    source='database',
                    target='backup',
                    message='Enabled databases require backups enabled',
                )
            )

        if state.security.ssl_required and not state.deployment.nginx_enabled:
            issues.append(
                DependencyIssue(
                    source='ssl',
                    target='nginx',
                    message='SSL requires Nginx deployment enabled',
                )
            )

        return issues

    def diff_states(
        self,
        current: DesiredState,
        desired: DesiredState,
    ) -> ConfigDiff:
        diff = ConfigDiff()
        current_data = self.state_to_dict(current)
        desired_data = self.state_to_dict(desired)

        def walk(prefix: str, left: Any, right: Any):
            if isinstance(left, dict) and isinstance(right, dict):
                keys = set(left.keys()) | set(right.keys())
                for key in sorted(keys):
                    walk(
                        f'{prefix}.{key}' if prefix else str(key),
                        left.get(key),
                        right.get(key),
                    )
                return

            if left != right:
                diff.changes.append(f'{prefix}:{left}->{right}')

        walk('', current_data, desired_data)
        return diff

    def export_json(self, state: DesiredState) -> Dict[str, Any]:
        return self.state_to_dict(state)

    def export_yaml(self, state: DesiredState) -> str:
        return yaml.safe_dump(
            self.export_json(state),
            sort_keys=False,
            allow_unicode=True,
        )

    def export_markdown(self, state: DesiredState) -> str:
        lines = [
            f'# Desired State: {state.environment}',
            '',
            f'- Schema Version: {state.schema_version}',
            f'- Services: {len(state.services)}',
            f'- Providers: {len(state.providers)}',
            f'- Modules: {len(state.modules)}',
            f'- Databases: {len(state.databases)}',
            f'- Integrations: {len(state.integrations)}',
            f'- Checksum: {state.checksum}',
        ]

        return '\n'.join(lines)

    def export_all(self, state: DesiredState) -> ConfigExport:
        return ConfigExport(
            json=self.export_json(state),
            yaml=self.export_yaml(state),
            markdown=self.export_markdown(state),
        )

    def migrate_schema(self, raw: Dict[str, Any]) -> Dict[str, Any]:
        version = raw.get('schema_version', 1)

        if version == 1:
            return raw

        return raw

    def validate_profile(self, environment: str) -> ConfigProfile:
        known = {
            'development': ConfigProfile(
                name='development',
                description='Local development profile',
            ),
            'staging': ConfigProfile(
                name='staging',
                inherits_from='development',
                description='Production-like validation profile',
            ),
            'production': ConfigProfile(
                name='production',
                inherits_from='staging',
                description='Production deployment profile',
            ),
            'enterprise': ConfigProfile(
                name='enterprise',
                inherits_from='production',
                description='Large scale deployment profile',
            ),
        }

        return known.get(
            environment,
            ConfigProfile(name=environment),
        )

    def build_desired_state(self, environment: str = 'production') -> DesiredState:
        base_policy = self.load_yaml('policies/development.yaml')
        # load and merge policies
        policies = self.merge_dicts(
            base_policy,
            self.load_environment(environment),
        )
        services = self.load_services()
        models = self.load_models()
        modules = self.load_modules()
        databases = self.load_database()
        integrations = self.load_integrations()
        deployment = self.load_deployment()
        monitoring = self.load_monitoring()
        notifications = self.load_notifications()
        repository = self.load_repository()
        installer = self.load_installer()

        # Normalize list/dict YAML shapes
        services = self.normalize_collection(services.get('services', services))
        models = self.normalize_collection(models.get('providers', models))
        modules = self.normalize_collection(modules.get('modules', modules))
        databases = self.normalize_collection(databases.get('databases', databases))
        integrations = self.normalize_collection(integrations.get('integrations', integrations))

        desired = DesiredState(environment=environment)

        for name, raw_cfg in services.items():
            cfg = self.normalize_config_item(raw_cfg)
            desired.services[name] = ServiceConfig(
                enabled=cfg.get('enabled', False),
                required=cfg.get('required', False),
                version=cfg.get('version'),
            )

        for name, raw_cfg in models.items():
            cfg = self.normalize_config_item(raw_cfg)
            desired.providers[name] = AIProviderConfig(
                enabled=cfg.get('enabled', False),
                api_key_env=cfg.get('api_key_env'),
                model=cfg.get('model'),
            )

            resolved = self.resolve_secret(
                cfg.get('api_key_env')
            )

            if resolved:
                desired.providers[name].api_key_env = cfg.get('api_key_env')

        for name, raw_cfg in modules.items():
            cfg = self.normalize_config_item(raw_cfg)
            desired.modules[name] = ModuleConfig(
                enabled=cfg.get('enabled', False),
                required=cfg.get('required', False),
            )

        for name, raw_cfg in databases.items():
            cfg = self.normalize_config_item(raw_cfg)
            desired.databases[name] = DatabaseConfig(
                engine=cfg.get('engine', 'postgresql'),
                enabled=cfg.get('enabled', False),
                host=cfg.get('host', 'localhost'),
                port=cfg.get('port', 5432),
            )

        for name, raw_cfg in integrations.items():
            cfg = self.normalize_config_item(raw_cfg)
            desired.integrations[name] = IntegrationConfig(
                enabled=cfg.get('enabled', False),
                token_env=cfg.get('token_env'),
            )

        desired.deployment = self.safe_dataclass(
            DeploymentConfig,
            deployment.get('deployment', deployment),
        )
        desired.monitoring = self.safe_dataclass(
            MonitoringConfig,
            monitoring.get('monitoring', monitoring),
        )
        desired.notifications = self.safe_dataclass(
            NotificationConfig,
            notifications.get('notifications', notifications),
        )
        desired.repository = self.safe_dataclass(
            RepositoryConfig,
            repository.get('repository', repository),
        )
        desired.installer = self.safe_dataclass(
            InstallerConfig,
            installer.get('installer', installer),
        )

        desired.security = SecurityConfig(
            ssl_required=policies.get('ssl_required', True),
            firewall_required=policies.get('firewall_required', True),
            backups_required=policies.get('backup_required', True),
        )

        desired.schema_version = 1

        desired.validation_issues = self.validate_desired_state(desired)
        desired.dependency_issues = self.validate_dependencies(desired)
        desired.checksum = self.calculate_checksum(desired).value

        return desired


# Config Engine V9 Final
CONFIG_ENGINE_VERSION = 'V9'
