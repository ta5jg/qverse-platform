from __future__ import annotations

import json
import os
import platform
import shutil
import socket
import subprocess
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Dict, List, Optional

import urllib.request

# Q-Verse State Engine Roadmap
#
# Current Phase:
#   State Engine v4
#
# Next Refactor Targets:
#   installer/core/state/
#       discovery.py
#       analysis.py
#       compliance.py
#       planning.py
#       telemetry.py
#       history.py
#
# Goals:
#   - Replace generic Dict usage with typed dataclasses
#   - Add Linux/macOS/Windows compatibility adapters
#   - Add Docker SDK integration
#   - Add PostgreSQL connection validation
#   - Add YAML policy loading from machine/*.yaml
#   - Add unit test coverage
#   - Keep state.py as orchestration layer only


@dataclass
class ServiceState:
    name: str
    installed: bool = False
    version: Optional[str] = None
    running: bool = False


@dataclass
class SystemState:
    hostname: str
    os_name: str
    os_version: str
    architecture: str
    hardware: Dict = field(default_factory=dict)
    packages: Dict = field(default_factory=dict)
    services: List[ServiceState] = field(default_factory=list)
    docker: Dict = field(default_factory=dict)
    databases: Dict = field(default_factory=dict)
    domains: List[str] = field(default_factory=list)
    ssl: Dict = field(default_factory=dict)
    qverse: Dict = field(default_factory=dict)
    models: Dict = field(default_factory=dict)
    integrations: Dict = field(default_factory=dict)
    projects: List[Dict] = field(default_factory=list)
    ram: Dict = field(default_factory=dict)
    disk: Dict = field(default_factory=dict)
    public_ip: Optional[str] = None
    firewall: Dict = field(default_factory=dict)
    systemd_services: List[str] = field(default_factory=list)
    containers: List[Dict] = field(default_factory=list)
    postgres_databases: List[str] = field(default_factory=list)
    redis_status: Dict = field(default_factory=dict)
    git_repositories: List[Dict] = field(default_factory=list)
    qverse_modules: List[str] = field(default_factory=list)
    admin_panel: Dict = field(default_factory=dict)
    api_health: Dict = field(default_factory=dict)
    backups: List[Dict] = field(default_factory=list)


@dataclass
class Recommendation:
    severity: str
    message: str


@dataclass
class StateAnalysis:
    score: int
    health: str
    missing_components: List[str] = field(default_factory=list)
    recommendations: List[Recommendation] = field(default_factory=list)


# --- Profiling, Risk, Compliance, Planning ---
@dataclass
class EnvironmentProfile:
    environment: str
    confidence: int


@dataclass
class RiskItem:
    severity: str
    component: str
    impact: str


@dataclass
class ComplianceReport:
    passed: bool
    score: int
    failed_checks: List[str] = field(default_factory=list)



@dataclass
class InstallationPlan:
    actions: List[str] = field(default_factory=list)


# --- Capacity, Drift, Dependency Impact, Repair Actions ---
@dataclass
class CapacityReport:
    max_agents: int
    profile: str


@dataclass
class DriftReport:
    detected: bool
    items: List[str] = field(default_factory=list)



@dataclass
class RepairAction:
    action: str
    command: str
    risk: str


# --- Deployment, AI Readiness, Executive Summary ---
@dataclass
class DeploymentReadiness:
    ready: bool
    blocking_issues: List[str] = field(default_factory=list)


@dataclass
class AIReadiness:
    score: int
    providers: Dict = field(default_factory=dict)


@dataclass
class ExecutiveSummary:
    health_score: int
    environment: str
    compliance_score: int
    deployment_ready: bool
    next_action: str


# --- Final Readiness, Security, Cost, Backup, Provider, History ---
@dataclass
class SecurityScore:
    score: int
    findings: List[str] = field(default_factory=list)


@dataclass
class BackupReadiness:
    ready: bool
    backup_count: int


@dataclass
class ProviderReadiness:
    score: int
    available: List[str] = field(default_factory=list)



@dataclass
class CostEstimate:
    monthly_usd: float
    profile: str


# --- Final modules: TelemetryReport, BenchmarkReport, PolicyReport ---
@dataclass
class TelemetryReport:
    health_trend: str
    security_trend: str
    performance_trend: str


@dataclass
class BenchmarkReport:
    cpu_score: int
    ram_score: int
    disk_score: int
    overall_score: int


@dataclass
class PolicyReport:
    passed: bool
    violations: List[str] = field(default_factory=list)


#
# NOTE:
# This file is intentionally acting as the orchestration layer.
# As the platform grows, discovery, analysis, compliance,
# planning, telemetry and history engines should be extracted
# into dedicated modules while preserving the public API of
# StateManager.
#
class StateManager:
    def __init__(self, state_file: str = '.qverse_state.json'):
        self.state_file = Path(state_file)
        self.history_dir = Path('.qverse_history')
        self.history_dir.mkdir(exist_ok=True)

    def command_exists(self, command: str) -> bool:
        return shutil.which(command) is not None

    def get_version(self, command: List[str]) -> Optional[str]:
        try:
            result = subprocess.run(
                command,
                capture_output=True,
                text=True,
                timeout=5,
            )
            output = (result.stdout or result.stderr).strip()
            return output.splitlines()[0] if output else None
        except Exception:
            return None

    def service_running(self, process_name: str) -> bool:
        try:
            result = subprocess.run(
                ['pgrep', '-f', process_name],
                capture_output=True,
                timeout=5,
            )
            return result.returncode == 0
        except Exception:
            return False

    def detect_hardware(self) -> Dict:
        return {
            'cpu_count': os.cpu_count(),
            'architecture': platform.machine(),
        }

    def detect_packages(self) -> Dict:
        return {
            'python': self.get_version(['python3', '--version']),
            'git': self.get_version(['git', '--version']),
            'node': self.get_version(['node', '--version']),
            'npm': self.get_version(['npm', '--version']),
        }

    def detect_docker(self) -> Dict:
        return {
            'installed': self.command_exists('docker'),
            'version': self.get_version(['docker', '--version']),
        }

    def detect_databases(self) -> Dict:
        return {
            'postgres': self.command_exists('psql'),
            'redis': self.command_exists('redis-server'),
        }

    def detect_domains(self) -> List[str]:
        nginx_dir = Path('/etc/nginx/sites-enabled')
        domains = []

        if nginx_dir.exists():
            for item in nginx_dir.iterdir():
                domains.append(item.name)

        return sorted(domains)

    def detect_ssl(self) -> Dict:
        letsencrypt = Path('/etc/letsencrypt/live')

        return {
            'enabled': letsencrypt.exists(),
            'certificates': [p.name for p in letsencrypt.iterdir()] if letsencrypt.exists() else [],
        }

    def detect_qverse(self) -> Dict:
        root = Path('/opt/ai-agents')

        return {
            'installed': root.exists(),
            'path': str(root),
        }

    def detect_models(self) -> Dict:
        return {
            'gemini': True,
            'openai': True,
            'anthropic': True,
            'deepseek': True,
            'openrouter': True,
            'ollama': self.command_exists('ollama'),
            'lmstudio': False,
        }

    def detect_integrations(self) -> Dict:
        return {
            'telegram': False,
            'discord': False,
            'slack': False,
            'signal': False,
            'whatsapp': False,
            'email': False,
        }

    def detect_projects(self) -> List[Dict]:
        projects_dir = Path('/opt/ai-agents/projects')
        projects = []

        if projects_dir.exists():
            for project in projects_dir.iterdir():
                if project.is_dir():
                    projects.append({
                        'name': project.name,
                        'path': str(project),
                    })

        return sorted(projects, key=lambda p: p['name'])

    def detect_ram(self) -> Dict:
        try:
            pages = os.sysconf('SC_PHYS_PAGES')
            page_size = os.sysconf('SC_PAGE_SIZE')
            total = pages * page_size
            return {'total_bytes': total}
        except Exception:
            return {}

    def detect_disk_usage(self) -> Dict:
        usage = shutil.disk_usage('/')
        return {
            'total': usage.total,
            'used': usage.used,
            'free': usage.free,
        }

    def detect_public_ip(self) -> Optional[str]:
        try:
            return urllib.request.urlopen('https://api.ipify.org', timeout=5).read().decode().strip()
        except Exception:
            return None

    def detect_firewall(self) -> Dict:
        return {
            'ufw_installed': self.command_exists('ufw'),
        }

    def detect_systemd_services(self) -> List[str]:
        try:
            result = subprocess.run(
                ['systemctl', 'list-units', '--type=service', '--state=running', '--no-legend'],
                capture_output=True,
                text=True,
                timeout=10,
            )
            return [line.split()[0] for line in result.stdout.splitlines() if line.strip()]
        except Exception:
            return []

    def detect_running_containers(self) -> List[Dict]:
        if not self.command_exists('docker'):
            return []

        try:
            result = subprocess.run(
                ['docker', 'ps', '--format', '{{.Names}}|{{.Image}}'],
                capture_output=True,
                text=True,
                timeout=10,
            )
            containers = []
            for line in result.stdout.splitlines():
                if '|' in line:
                    name, image = line.split('|', 1)
                    containers.append({'name': name, 'image': image})
            return containers
        except Exception:
            return []

    def detect_postgres_databases(self) -> List[str]:
        if not self.command_exists('psql'):
            return []

        try:
            result = subprocess.run(
                ['psql', '-lqt'],
                capture_output=True,
                text=True,
                timeout=10,
            )
            dbs = []
            for line in result.stdout.splitlines():
                if '|' in line:
                    dbs.append(line.split('|')[0].strip())
            return sorted(set(dbs))
        except Exception:
            return []

    def detect_redis_status(self) -> Dict:
        return {
            'installed': self.command_exists('redis-server'),
            'running': self.service_running('redis'),
        }

    def detect_git_repositories(self) -> List[Dict]:
        roots = [Path('/opt/ai-agents/projects')]
        repos = []

        for root in roots:
            if not root.exists():
                continue
            for item in root.iterdir():
                if (item / '.git').exists():
                    repos.append({'name': item.name, 'path': str(item)})

        return repos

    def detect_qverse_modules(self) -> List[str]:
        modules = []
        installer_dir = Path.cwd().parent
        for name in ['core', 'services', 'models', 'integrations', 'frontend', 'database']:
            if (installer_dir / name).exists():
                modules.append(name)
        return modules

    def detect_admin_panel(self) -> Dict:
        admin = Path('/opt/ai-agents/qverse-admin')
        return {
            'installed': admin.exists(),
            'path': str(admin),
        }

    def detect_api_health(self) -> Dict:
        try:
            with urllib.request.urlopen('http://127.0.0.1:8787/health', timeout=3) as response:
                return {'reachable': response.status == 200}
        except Exception:
            return {'reachable': False}

    def detect_backups(self) -> List[Dict]:
        backup_dir = Path('./backups')
        if not backup_dir.exists():
            return []

        return [
            {'name': f.name, 'size': f.stat().st_size}
            for f in backup_dir.iterdir()
            if f.is_file()
        ]

    def detect_services(self) -> List[ServiceState]:
        services = []

        registry = [
            ('node', ['node', '--version'], 'node'),
            ('docker', ['docker', '--version'], 'docker'),
            ('postgres', ['psql', '--version'], 'postgres'),
            ('redis', ['redis-server', '--version'], 'redis'),
            ('nginx', ['nginx', '-v'], 'nginx'),
        ]

        for name, version_cmd, process_name in registry:
            installed = self.command_exists(version_cmd[0])
            version = self.get_version(version_cmd) if installed else None
            running = self.service_running(process_name)

            services.append(
                ServiceState(
                    name=name,
                    installed=installed,
                    version=version,
                    running=running,
                )
            )

        return services

    def detect(self) -> SystemState:
        return SystemState(
            hostname=socket.gethostname(),
            os_name=platform.system(),
            os_version=platform.version(),
            architecture=platform.machine(),
            hardware=self.detect_hardware(),
            packages=self.detect_packages(),
            services=self.detect_services(),
            docker=self.detect_docker(),
            databases=self.detect_databases(),
            domains=self.detect_domains(),
            ssl=self.detect_ssl(),
            qverse=self.detect_qverse(),
            models=self.detect_models(),
            integrations=self.detect_integrations(),
            projects=self.detect_projects(),
            ram=self.detect_ram(),
            disk=self.detect_disk_usage(),
            public_ip=self.detect_public_ip(),
            firewall=self.detect_firewall(),
            systemd_services=self.detect_systemd_services(),
            containers=self.detect_running_containers(),
            postgres_databases=self.detect_postgres_databases(),
            redis_status=self.detect_redis_status(),
            git_repositories=self.detect_git_repositories(),
            qverse_modules=self.detect_qverse_modules(),
            admin_panel=self.detect_admin_panel(),
            api_health=self.detect_api_health(),
            backups=self.detect_backups(),
        )

    def analyze(self, state: SystemState) -> StateAnalysis:
        score = 100
        missing = []
        recommendations = []

        critical_services = ['node', 'postgres', 'nginx']

        service_map = {s.name: s for s in state.services}

        for service in critical_services:
            svc = service_map.get(service)
            if not svc or not svc.installed:
                score -= 15
                missing.append(service)
                recommendations.append(
                    Recommendation(
                        severity='critical',
                        message=f'Install {service}',
                    )
                )

        if not state.redis_status.get('installed'):
            score -= 5
            missing.append('redis')
            recommendations.append(
                Recommendation(
                    severity='warning',
                    message='Install Redis cache layer',
                )
            )

        if not state.ssl.get('enabled'):
            score -= 10
            recommendations.append(
                Recommendation(
                    severity='critical',
                    message='Configure SSL certificates',
                )
            )

        if not state.api_health.get('reachable'):
            score -= 15
            recommendations.append(
                Recommendation(
                    severity='critical',
                    message='Q-Verse API is not reachable',
                )
            )

        if not state.admin_panel.get('installed'):
            score -= 10
            recommendations.append(
                Recommendation(
                    severity='warning',
                    message='Install Admin Panel',
                )
            )

        score = max(0, min(score, 100))

        if score >= 90:
            health = 'excellent'
        elif score >= 75:
            health = 'good'
        elif score >= 50:
            health = 'warning'
        else:
            health = 'critical'

        return StateAnalysis(
            score=score,
            health=health,
            missing_components=missing,
            recommendations=recommendations,
        )

    def build_environment_profile(self, state: SystemState) -> EnvironmentProfile:
        score = 0

        if state.ssl.get('enabled'):
            score += 25

        if state.admin_panel.get('installed'):
            score += 20

        if state.api_health.get('reachable'):
            score += 20

        if len(state.systemd_services) > 10:
            score += 15

        if state.redis_status.get('installed'):
            score += 10

        if state.docker.get('installed'):
            score += 10

        if score >= 75:
            return EnvironmentProfile('production', score)
        elif score >= 40:
            return EnvironmentProfile('staging', score)
        else:
            return EnvironmentProfile('development', score)

    def build_dependency_graph(self, state: SystemState) -> Dict:
        return {
            'memory_engine': ['postgres', 'redis'],
            'agent_orchestrator': ['memory_engine', 'model_router'],
            'model_router': ['providers'],
            'admin_panel': ['api_gateway'],
            'api_gateway': ['postgres', 'redis'],
            'tool_engine': ['docker', 'system', 'git'],
        }

    def assess_risks(self, state: SystemState) -> List[RiskItem]:
        risks = []

        if not state.ssl.get('enabled'):
            risks.append(RiskItem('critical', 'ssl', 'Traffic is not encrypted'))

        if not state.redis_status.get('installed'):
            risks.append(RiskItem('medium', 'redis', 'Caching and memory acceleration unavailable'))

        if not state.backups:
            risks.append(RiskItem('high', 'backup', 'No recovery point available'))

        if not state.api_health.get('reachable'):
            risks.append(RiskItem('critical', 'api', 'Core API unavailable'))

        return risks

    def evaluate_compliance(self, state: SystemState) -> ComplianceReport:
        failed = []
        score = 100

        if not state.ssl.get('enabled'):
            failed.append('ssl')
            score -= 25

        if not state.backups:
            failed.append('backup_policy')
            score -= 20

        if not state.api_health.get('reachable'):
            failed.append('api_health')
            score -= 25

        if not state.firewall.get('ufw_installed'):
            failed.append('firewall')
            score -= 10

        return ComplianceReport(
            passed=len(failed) == 0,
            score=max(0, score),
            failed_checks=failed,
        )

    def build_installation_plan(self, state: SystemState) -> InstallationPlan:
        actions = []

        if not state.redis_status.get('installed'):
            actions.append('install_redis')

        if not state.ssl.get('enabled'):
            actions.append('configure_ssl')

        if not state.admin_panel.get('installed'):
            actions.append('install_admin_panel')

        if not state.api_health.get('reachable'):
            actions.append('deploy_qverse_api')

        if not state.backups:
            actions.append('configure_backup_system')

        return InstallationPlan(actions=actions)

    def calculate_capacity(self, state: SystemState) -> CapacityReport:
        cpu_count = state.hardware.get('cpu_count') or 1
        ram_bytes = state.ram.get('total_bytes') or 0
        ram_gb = ram_bytes / (1024 ** 3)

        estimated = max(1, int(min(cpu_count * 4, ram_gb * 2)))

        if estimated >= 50:
            profile = 'enterprise'
        elif estimated >= 20:
            profile = 'production'
        elif estimated >= 5:
            profile = 'small_business'
        else:
            profile = 'development'

        return CapacityReport(
            max_agents=estimated,
            profile=profile,
        )

    def detect_drift(self, state: SystemState) -> DriftReport:
        drift = []

        if state.redis_status.get('installed') and not state.redis_status.get('running'):
            drift.append('redis_installed_but_not_running')

        if state.admin_panel.get('installed') and not state.api_health.get('reachable'):
            drift.append('admin_present_api_unreachable')

        if state.ssl.get('enabled') and not state.domains:
            drift.append('ssl_present_without_detected_domain')

        return DriftReport(
            detected=len(drift) > 0,
            items=drift,
        )

    def dependency_impacts(self, state: SystemState) -> Dict:
        impacts = {}

        if not state.redis_status.get('installed'):
            impacts['redis'] = [
                'memory_engine',
                'agent_context_cache',
                'performance_layer',
            ]

        if not state.api_health.get('reachable'):
            impacts['api'] = [
                'admin_panel',
                'agents',
                'integrations',
            ]

        return impacts

    def build_repair_actions(self, state: SystemState) -> List[RepairAction]:
        actions = []

        if not state.redis_status.get('installed'):
            actions.append(
                RepairAction(
                    action='install_redis',
                    command='apt-get install redis-server -y',
                    risk='low',
                )
            )

        if not state.ssl.get('enabled'):
            actions.append(
                RepairAction(
                    action='configure_ssl',
                    command='certbot --nginx',
                    risk='medium',
                )
            )

        if not state.api_health.get('reachable'):
            actions.append(
                RepairAction(
                    action='restart_qverse_api',
                    command='systemctl restart qverse-ai-api',
                    risk='low',
                )
            )

        return actions

    def evaluate_deployment_readiness(self, state: SystemState) -> DeploymentReadiness:
        blocking = []

        if not state.api_health.get('reachable'):
            blocking.append('api_unreachable')

        if not state.ssl.get('enabled'):
            blocking.append('ssl_missing')

        if not state.redis_status.get('installed'):
            blocking.append('redis_missing')

        return DeploymentReadiness(
            ready=len(blocking) == 0,
            blocking_issues=blocking,
        )

    def evaluate_ai_readiness(self, state: SystemState) -> AIReadiness:
        providers = state.models.copy()

        score = 0
        for enabled in providers.values():
            if enabled:
                score += 10

        score = min(score, 100)

        return AIReadiness(
            score=score,
            providers=providers,
        )

    def build_executive_summary(
        self,
        analysis: StateAnalysis,
        profile: EnvironmentProfile,
        compliance: ComplianceReport,
        readiness: DeploymentReadiness,
        plan: InstallationPlan,
    ) -> ExecutiveSummary:

        next_action = plan.actions[0] if plan.actions else 'none'

        return ExecutiveSummary(
            health_score=analysis.score,
            environment=profile.environment,
            compliance_score=compliance.score,
            deployment_ready=readiness.ready,
            next_action=next_action,
        )

    def evaluate_security_score(self, state: SystemState) -> SecurityScore:
        score = 100
        findings = []

        if not state.ssl.get('enabled'):
            score -= 30
            findings.append('ssl_missing')

        if not state.firewall.get('ufw_installed'):
            score -= 15
            findings.append('firewall_missing')

        if not state.backups:
            score -= 15
            findings.append('backup_missing')

        return SecurityScore(max(0, score), findings)

    def evaluate_backup_readiness(self, state: SystemState) -> BackupReadiness:
        return BackupReadiness(
            ready=len(state.backups) > 0,
            backup_count=len(state.backups),
        )

    def evaluate_provider_readiness(self, state: SystemState) -> ProviderReadiness:
        available = [k for k, v in state.models.items() if v]

        return ProviderReadiness(
            score=min(100, len(available) * 10),
            available=available,
        )

    def estimate_cost(self, state: SystemState) -> CostEstimate:
        agents = max(1, len(state.projects))
        estimated = round(agents * 5.0, 2)

        if estimated < 25:
            profile = 'development'
        elif estimated < 100:
            profile = 'business'
        else:
            profile = 'enterprise'

        return CostEstimate(
            monthly_usd=estimated,
            profile=profile,
        )

    def benchmark_system(self, state: SystemState) -> BenchmarkReport:
        cpu_score = min(100, (state.hardware.get('cpu_count') or 1) * 8)

        ram_gb = (state.ram.get('total_bytes') or 0) / (1024 ** 3)
        ram_score = min(100, int(ram_gb * 4))

        disk_free = state.disk.get('free', 0)
        disk_score = 100 if disk_free > 100 * 1024**3 else 70

        overall = int((cpu_score + ram_score + disk_score) / 3)

        return BenchmarkReport(
            cpu_score=cpu_score,
            ram_score=ram_score,
            disk_score=disk_score,
            overall_score=overall,
        )

    def evaluate_policies(self, state: SystemState) -> PolicyReport:
        violations = []

        if not state.ssl.get('enabled'):
            violations.append('ssl_required')

        if not state.backups:
            violations.append('backup_required')

        if not state.firewall.get('ufw_installed'):
            violations.append('firewall_required')

        return PolicyReport(
            passed=len(violations) == 0,
            violations=violations,
        )

    def build_telemetry(self) -> TelemetryReport:
        history = sorted(self.history_dir.glob('*.json'))

        if len(history) < 2:
            return TelemetryReport(
                health_trend='unknown',
                security_trend='unknown',
                performance_trend='unknown',
            )

        return TelemetryReport(
            health_trend='stable',
            security_trend='stable',
            performance_trend='stable',
        )

    def save_history_snapshot(self, snapshot: Dict) -> None:
        import datetime

        ts = datetime.datetime.utcnow().strftime('%Y%m%d_%H%M%S')
        target = self.history_dir / f'{ts}.json'
        target.write_text(json.dumps(snapshot, indent=2), encoding='utf-8')

    def latest_snapshot(self) -> Optional[Dict]:
        files = sorted(self.history_dir.glob('*.json'))
        if not files:
            return None

        return json.loads(files[-1].read_text(encoding='utf-8'))

    def diff_against_previous(self, current: Dict) -> Dict:
        previous = self.latest_snapshot()

        if not previous:
            return {'available': False, 'changes': []}

        changes = []

        prev_score = previous.get('analysis', {}).get('score')
        curr_score = current.get('analysis', {}).get('score')

        if prev_score != curr_score:
            changes.append(
                f'health_score: {prev_score} -> {curr_score}'
            )

        return {
            'available': True,
            'changes': changes,
        }

    def generate_snapshot(self) -> Dict:
        state = self.detect()
        analysis = self.analyze(state)
        profile = self.build_environment_profile(state)
        dependencies = self.build_dependency_graph(state)
        risks = self.assess_risks(state)
        compliance = self.evaluate_compliance(state)
        plan = self.build_installation_plan(state)

        capacity = self.calculate_capacity(state)
        drift = self.detect_drift(state)
        impacts = self.dependency_impacts(state)
        repairs = self.build_repair_actions(state)

        deployment = self.evaluate_deployment_readiness(state)
        ai_readiness = self.evaluate_ai_readiness(state)
        executive = self.build_executive_summary(
            analysis,
            profile,
            compliance,
            deployment,
            plan,
        )

        security = self.evaluate_security_score(state)
        backup_readiness = self.evaluate_backup_readiness(state)
        provider_readiness = self.evaluate_provider_readiness(state)
        cost_estimate = self.estimate_cost(state)

        # New final modules
        benchmark = self.benchmark_system(state)
        policies = self.evaluate_policies(state)
        telemetry = self.build_telemetry()

        snapshot = {
            'state': asdict(state),
            'analysis': {
                'score': analysis.score,
                'health': analysis.health,
                'missing_components': analysis.missing_components,
                'recommendations': [
                    {
                        'severity': r.severity,
                        'message': r.message,
                    }
                    for r in analysis.recommendations
                ],
            },
            'environment_profile': {
                'environment': profile.environment,
                'confidence': profile.confidence,
            },
            'dependencies': dependencies,
            'risks': [
                {
                    'severity': r.severity,
                    'component': r.component,
                    'impact': r.impact,
                }
                for r in risks
            ],
            'compliance': {
                'passed': compliance.passed,
                'score': compliance.score,
                'failed_checks': compliance.failed_checks,
            },
            'installation_plan': {
                'actions': plan.actions,
            },
            'capacity': {
                'max_agents': capacity.max_agents,
                'profile': capacity.profile,
            },
            'drift': {
                'detected': drift.detected,
                'items': drift.items,
            },
            'dependency_impacts': impacts,
            'repair_actions': [
                {
                    'action': r.action,
                    'command': r.command,
                    'risk': r.risk,
                }
                for r in repairs
            ],
            'deployment_readiness': {
                'ready': deployment.ready,
                'blocking_issues': deployment.blocking_issues,
            },
            'ai_readiness': {
                'score': ai_readiness.score,
                'providers': ai_readiness.providers,
            },
            'executive_summary': {
                'health_score': executive.health_score,
                'environment': executive.environment,
                'compliance_score': executive.compliance_score,
                'deployment_ready': executive.deployment_ready,
                'next_action': executive.next_action,
                'security_score': security.score,
                'provider_score': provider_readiness.score,
                'benchmark_score': benchmark.overall_score,
            },
            'security': {
                'score': security.score,
                'findings': security.findings,
            },
            'backup_readiness': {
                'ready': backup_readiness.ready,
                'backup_count': backup_readiness.backup_count,
            },
            'provider_readiness': {
                'score': provider_readiness.score,
                'available': provider_readiness.available,
            },
            'cost_estimate': {
                'monthly_usd': cost_estimate.monthly_usd,
                'profile': cost_estimate.profile,
            },
            'benchmark': {
                'cpu_score': benchmark.cpu_score,
                'ram_score': benchmark.ram_score,
                'disk_score': benchmark.disk_score,
                'overall_score': benchmark.overall_score,
            },
            'policies': {
                'passed': policies.passed,
                'violations': policies.violations,
            },
            'telemetry': {
                'health_trend': telemetry.health_trend,
                'security_trend': telemetry.security_trend,
                'performance_trend': telemetry.performance_trend,
            },
        }
        snapshot['state_diff'] = self.diff_against_previous(snapshot)
        self.save_history_snapshot(snapshot)
        return snapshot

    def save(self, state: SystemState) -> None:
        self.state_file.write_text(
            json.dumps(asdict(state), indent=2),
            encoding='utf-8',
        )

    def load(self) -> Dict:
        if not self.state_file.exists():
            return {}

        return json.loads(self.state_file.read_text(encoding='utf-8'))


if __name__ == '__main__':
    manager = StateManager()

    snapshot = manager.generate_snapshot()

    manager.state_file.write_text(
        json.dumps(snapshot, indent=2),
        encoding='utf-8',
    )

    print(json.dumps(snapshot, indent=2))