"""
Q-Verse Platform Installer V4 / V9 Orchestrator

Master Orchestrator

Flow:
    State Engine
        ↓
    Config Engine
        ↓
    Audit Engine
        ↓
    Backup Engine
        ↓
    Planner
        ↓
    Execution
        ↓
    Validation
        ↓
    Logger Engine
"""

from __future__ import annotations

import argparse
import json
import subprocess
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

from installer.core import (
    AuditEngine,
    BackupEngine,
    ConfigManager,
    LoggerEngine,
    runtime_report,
)
from installer.core.backup import BackupTarget

try:
    from installer.core.state import StateManager
except Exception:
    StateManager = None


INSTALLER_VERSION = "V4"
INSTALLER_STATUS = "V9_ENTERPRISE_ORCHESTRATOR"


@dataclass
class InstallerAction:
    name: str
    category: str
    command: Optional[str] = None
    risk: str = "low"
    requires_backup: bool = False
    executed: bool = False
    success: Optional[bool] = None
    output: Optional[str] = None


@dataclass
class InstallerPlan:
    mode: str
    environment: str
    dry_run: bool = True
    actions: List[InstallerAction] = field(default_factory=list)
    backup_required: bool = False
    rollback_available: bool = False


@dataclass
class InstallerValidation:
    passed: bool
    checks: Dict[str, bool] = field(default_factory=dict)
    errors: List[str] = field(default_factory=list)


@dataclass
class InstallerResult:
    started_at: str
    completed_at: str
    success: bool
    mode: str
    environment: str
    dry_run: bool
    runtime: Dict[str, Any]
    plan: Dict[str, Any] = field(default_factory=dict)
    validation: Dict[str, Any] = field(default_factory=dict)
    summary: Dict[str, Any] = field(default_factory=dict)


class QVerseInstaller:
    """Enterprise orchestrator for Q-Verse installation lifecycle."""

    def __init__(self):
        self.logger = LoggerEngine()
        self.config = ConfigManager()
        self.audit = AuditEngine()
        self.backup = BackupEngine()
        self.state = StateManager() if StateManager else None
        self.reports_dir = Path(".qverse_installer")
        self.reports_dir.mkdir(exist_ok=True)

    def now(self) -> str:
        return datetime.now(timezone.utc).isoformat()

    def detect_current_state(self) -> Dict[str, Any]:
        if self.state and hasattr(self.state, "generate_snapshot"):
            try:
                return self.state.generate_snapshot()
            except Exception as exc:
                self.logger.warning(
                    "installer",
                    "State engine failed; using fallback state",
                    error=str(exc),
                )

        return {
            "state": {
                "services": [],
                "databases": {},
                "ssl": {"enabled": False},
                "firewall": {"ufw_installed": False},
                "backups": [],
                "api_health": {"reachable": False},
                "admin_panel": {"installed": False},
            }
        }

    def build_plan(
        self,
        mode: str,
        environment: str,
        audit_report: Any,
        dry_run: bool,
    ) -> InstallerPlan:
        actions = []

        for action in audit_report.actions:
            actions.append(
                InstallerAction(
                    name=action.action,
                    category=action.category,
                    command=action.command,
                    risk=action.risk,
                    requires_backup=action.requires_backup,
                )
            )

        if mode == "audit":
            actions = []

        backup_required = any(action.requires_backup for action in actions)

        return InstallerPlan(
            mode=mode,
            environment=environment,
            dry_run=dry_run,
            actions=actions,
            backup_required=backup_required,
            rollback_available=backup_required,
        )

    def build_backup_targets(self) -> List[BackupTarget]:
        candidates = [
            BackupTarget("machine", "machine", "config", required=False),
            BackupTarget("installer", "installer", "code", required=False),
            BackupTarget("docs", "docs", "docs", required=False),
            BackupTarget("root_installer", "qverse_platform_installer_v4.py", "code", required=False),
        ]

        return [target for target in candidates if Path(target.path).exists()]

    def create_preflight_backup(self, plan: InstallerPlan):
        if not plan.backup_required:
            return None

        targets = self.build_backup_targets()

        if not targets:
            self.logger.warning("backup", "No backup targets found")
            return None

        self.logger.info("backup", "Creating preflight backup")
        report = self.backup.create_backup(targets)
        self.backup.save_report(report)
        return report

    def execute_action(self, action: InstallerAction, dry_run: bool = True) -> InstallerAction:
        if dry_run:
            action.executed = False
            action.success = True
            action.output = "dry-run"
            self.logger.info("execution", f"Dry-run action: {action.name}")
            return action

        self.logger.execution_start(action.name)

        if not action.command:
            action.executed = True
            action.success = True
            action.output = "no command; marked successful"
            self.logger.execution_complete(action.name, status="completed")
            return action

        try:
            result = subprocess.run(
                action.command,
                shell=True,
                text=True,
                capture_output=True,
                timeout=600,
            )
            action.executed = True
            action.success = result.returncode == 0
            action.output = (result.stdout or result.stderr or "").strip()
            self.logger.execution_complete(
                action.name,
                status="completed" if action.success else "failed",
            )
        except Exception as exc:
            action.executed = True
            action.success = False
            action.output = str(exc)
            self.logger.error("execution", f"Action failed: {action.name}", error=str(exc))
            self.logger.execution_complete(action.name, status="failed")

        return action

    def execute_plan(self, plan: InstallerPlan) -> InstallerPlan:
        for action in plan.actions:
            self.execute_action(action, dry_run=plan.dry_run)
        return plan

    def validate_installation(self, plan: InstallerPlan) -> InstallerValidation:
        checks = {
            "runtime_available": True,
            "plan_generated": bool(plan),
            "actions_sane": all(action.name for action in plan.actions),
        }

        errors = [name for name, passed in checks.items() if not passed]

        return InstallerValidation(
            passed=not errors,
            checks=checks,
            errors=errors,
        )

    def rollback(self, backup_report: Any) -> bool:
        if not backup_report or not backup_report.metadata:
            return False

        self.logger.warning("rollback", "Rollback requested")
        plan = self.backup.build_restore_plan(backup_report.metadata)
        return self.backup.restore_backup(backup_report.metadata, ".qverse_restore")

    def save_result(self, result: InstallerResult) -> Path:
        target = self.reports_dir / f"installer_{datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')}.json"
        target.write_text(json.dumps(asdict(result), indent=2, default=str), encoding="utf-8")
        return target

    def run(
        self,
        environment: str = "development",
        mode: str = "audit",
        dry_run: bool = True,
    ) -> InstallerResult:
        started = self.now()
        context = self.logger.new_context(user_id="system", request_id=f"installer-{started}")

        self.logger.info(
            "installer",
            f"Q-Verse installer started ({environment}, mode={mode}, dry_run={dry_run})",
            context=context,
        )

        desired_state = self.config.build_desired_state(environment)
        current_state = self.detect_current_state()

        audit_report = self.audit.run_audit(
            current_state=current_state,
            desired_state=desired_state,
        )

        plan = self.build_plan(
            mode=mode,
            environment=environment,
            audit_report=audit_report,
            dry_run=dry_run,
        )

        backup_report = self.create_preflight_backup(plan)

        if mode in {"install", "repair", "upgrade"}:
            plan = self.execute_plan(plan)

        validation = self.validate_installation(plan)

        success = validation.passed and all(
            action.success is not False
            for action in plan.actions
        )

        if not success and backup_report and not dry_run:
            self.rollback(backup_report)

        runtime = runtime_report()

        summary = {
            "installer_version": INSTALLER_VERSION,
            "installer_status": INSTALLER_STATUS,
            "audit_score": (
                audit_report.summary.score
                if audit_report.summary
                else None
            ),
            "findings": len(audit_report.findings),
            "actions": len(plan.actions),
            "backup_created": bool(backup_report),
            "validation_passed": validation.passed,
        }

        self.logger.info(
            "installer",
            "Q-Verse installer completed",
            context=context,
            audit_score=summary["audit_score"],
            success=success,
        )

        result = InstallerResult(
            started_at=started,
            completed_at=self.now(),
            success=success,
            mode=mode,
            environment=environment,
            dry_run=dry_run,
            runtime=runtime,
            plan=asdict(plan),
            validation=asdict(validation),
            summary=summary,
        )

        self.save_result(result)
        return result


def parse_args():
    parser = argparse.ArgumentParser(description="Q-Verse Platform Installer V4")
    parser.add_argument("--environment", default="development")
    parser.add_argument(
        "--mode",
        choices=["audit", "install", "repair", "upgrade"],
        default="audit",
    )
    parser.add_argument("--execute", action="store_true", help="Run real commands instead of dry-run")
    return parser.parse_args()


if __name__ == "__main__":
    args = parse_args()
    installer = QVerseInstaller()
    result = installer.run(
        environment=args.environment,
        mode=args.mode,
        dry_run=not args.execute,
    )

    print("Q-Verse Installer")
    print(json.dumps(asdict(result), indent=2, default=str))